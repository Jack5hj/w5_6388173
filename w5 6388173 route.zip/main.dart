import 'package:flutter/material.dart';

void main() => runApp(MyApp());


class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Contact Us',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: HomePage(),
    );
  }
}


class HomePage extends StatelessWidget {
   int _selectedIndex = 0;

  void _onTabTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }
  @override
 Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Home'),
        flexibleSpace: Container(
          decoration: BoxDecoration(
            image: DecorationImage(
              image: AssetImage('assets/images/4.png'), 
              fit: BoxFit.cover,
            ),
          ),
        ),
      ),
  body: GridView.builder(
  gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
    crossAxisCount: 2,
    mainAxisSpacing: 16.0,
    crossAxisSpacing: 16.0,
    childAspectRatio: 1.0, // 设置子项的宽高比
  ),
  padding: EdgeInsets.all(16.0),
  itemCount: 4,
  itemBuilder: (BuildContext context, int index) {
    return _buildButtonWithIconAndNavigate(
      context,
      index == 0 ? Icons.cases_rounded : (index == 1 ? Icons.room_service_outlined : (index == 2 ? Icons.phone : Icons.people)),
      index == 0 ? 'Product' : (index == 1 ? 'Service' : (index == 2 ? 'Contact us' : 'About us')),
      () {
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => index == 0 ? ProductScreen() : (index == 1 ? ServiceScreen() : (index == 2 ? ContactPage() : Aboutus()))),
        );
      },
    );
  },
),
              bottomNavigationBar: BottomNavigationBar(
        backgroundColor: const Color.fromARGB(255, 67, 81, 87),
        unselectedItemColor: Colors.black,
        selectedItemColor: Colors.black,
        items: [
          BottomNavigationBarItem(
    icon: Icon(Icons.home),
    label: 'Home',
  ),
  BottomNavigationBarItem(
    icon: Icon(Icons.shop),
    label: 'Shop',
  ),
  BottomNavigationBarItem(
    icon: Icon(Icons.code),
    label: 'QRscan',
  ),
  BottomNavigationBarItem(
    icon: Icon(Icons.person),
    label: 'Profile',
  ),
  BottomNavigationBarItem(
    icon: Icon(Icons.settings),
    label: 'Settings',
  ),
        ],
        currentIndex: _selectedIndex,
        onTap: _onTabTapped,
        ),
    );
  }

  Widget _buildButtonWithIconAndNavigate(BuildContext context, IconData icon, String label, VoidCallback onPressed) {
    return InkWell(
      onTap: onPressed,
        child:Container(
          width: 40,
          height: 40,
          color: Colors.blue,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            icon,
            size: 36.0,
          ),
          SizedBox(height: 8.0),
          Text(
            label,
            style: TextStyle(fontSize: 14.0),
          ),
        ],
      ),
      ),
      
    );
  }
}

void setState(Null Function() param0) {
}

class ProductScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Product Screen'),
      ),
      body: Center(
        child: Text('Product Screen'),
      ),
    );
  }
}

class ServiceScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Service Screen'),
      ),
      body: Center(
        child: Text('Service Screen'),
      ),
    );
  }
}


class Aboutus extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Aboutus Screen'),
      ),
      body: Center(
        child: Text('Aboutus Screen'),
      ),
    );
  }
}

class ContactPage extends StatefulWidget {
  @override
  _ContactPageState createState() => _ContactPageState();
}
class _ContactPageState extends State<ContactPage> {
  int _selectedIndex = 0;
  void _onTabTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Color.alphaBlend(Color.fromARGB(255, 97, 85, 207),Colors.black),
        flexibleSpace: FlexibleSpaceBar(
        title: Center(
        child: Text('Contact Us',
        textAlign: TextAlign.center,),
      ),
      ),
      ),
      body: Container(
        padding: EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            SizedBox(height: 12.0),
            Align(alignment: Alignment.centerLeft,
            child: Text(
              'Have Qustions?',
              style: TextStyle(
                fontSize: 24.0,
                fontWeight: FontWeight.bold,
                color:Colors.grey
                )
            ),
            ),
            SizedBox(height: 12.0),
            Align(alignment: Alignment.centerLeft,
            child:Text(
              'Shoot us an email',
              style: TextStyle(
                fontSize: 24.0,
                fontWeight: FontWeight.bold,
                color: Colors.grey,
              ),
            ),
            ),
            SizedBox(height: 12.0),
            TextFormField(
              decoration: InputDecoration(
                labelText: 'Topic...',
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 12.0),
            TextFormField(
              decoration: InputDecoration(
                labelText: 'E-mail',
                border: OutlineInputBorder(),
              ),
            ),
             SizedBox(height: 12.0),
            TextFormField(
              decoration: InputDecoration(
                labelText: 'Mobile number',
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 12.0),
            TextFormField(
              decoration: InputDecoration(
                labelText: 'Student code',
                border: OutlineInputBorder(),
              ),
              obscureText: true,
            ),
             SizedBox(height: 25.0),
            TextFormField(
              decoration: InputDecoration(
                labelText: 'Your Question',
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 12.0),
            Image.asset('assets/images/3.png',
            fit:BoxFit.fitWidth,
            ),
            SizedBox(height:12.0),
            Container(width: double.infinity,
          child: ElevatedButton(
            style: ElevatedButton.styleFrom(
              primary: Color.fromARGB(255, 21, 12, 145),
              onPrimary: Colors.white,
            ),
            child : const Text ('submmit') ,
              onPressed: () {
                Navigator . push (context ,
MaterialPageRoute ( builder :( context ) => const SecondRoute (),
) ,
);
              }, 
          ),
           ),
             ],
      ),
        ),
        bottomNavigationBar: BottomNavigationBar(
        backgroundColor: const Color.fromARGB(255, 67, 81, 87),
        unselectedItemColor: Colors.black,
        selectedItemColor: Colors.black,
        items: [
          BottomNavigationBarItem(
    icon: Icon(Icons.home),
    label: 'Home',
  ),
  BottomNavigationBarItem(
    icon: Icon(Icons.shop),
    label: 'Shop',
  ),
  BottomNavigationBarItem(
    icon: Icon(Icons.code),
    label: 'QRscan',
  ),
  BottomNavigationBarItem(
    icon: Icon(Icons.person),
    label: 'Profile',
  ),
  BottomNavigationBarItem(
    icon: Icon(Icons.settings),
    label: 'Settings',
  ),
        ],
        currentIndex: _selectedIndex,
        onTap: _onTabTapped,
        ),
    );
  }
}
class SecondRoute extends StatefulWidget {
  const SecondRoute({Key? key}) : super(key: key);

  @override
  _SecondRouteState createState() => _SecondRouteState();
}

class _SecondRouteState extends State<SecondRoute> {
  int _currentIndex = 0;

  void _onTabTapped(int index) {
    setState(() {
      _currentIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Contact Us'),
      ),
      body: Stack(
        children: [
          Positioned(
            top: 10.0,
            left: 10.0,
            child: ElevatedButton(
              onPressed: () {
                 Navigator . push (context ,
MaterialPageRoute ( builder :( context ) => HomePage (),
) ,
);
              },
              child: const Text('< Back to Homepage'),
            ),
          ),
          Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Image.asset(
                  'assets/images/2.png',
                  width: 200,
                  height: 200,
                ),
                const SizedBox(height: 10),
                Text(
                  'Submit Successful',
                  style: TextStyle(fontSize: 16),
                ),
              ],
            ),
          ),
        ],
      ),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        onTap: _onTabTapped,
        backgroundColor: const Color.fromARGB(255, 67, 81, 87),
        unselectedItemColor: Colors.black,
        selectedItemColor: Colors.black,
        items: [
          BottomNavigationBarItem(
    icon: Icon(Icons.home),
    label: 'Home',
  ),
  BottomNavigationBarItem(
    icon: Icon(Icons.shop),
    label: 'Shop',
  ),
  BottomNavigationBarItem(
    icon: Icon(Icons.code),
    label: 'QRscan',
  ),
  BottomNavigationBarItem(
    icon: Icon(Icons.person),
    label: 'Profile',
  ),
  BottomNavigationBarItem(
    icon: Icon(Icons.settings),
    label: 'Settings',
  ),
        ],
      ),
    );
  }
}
